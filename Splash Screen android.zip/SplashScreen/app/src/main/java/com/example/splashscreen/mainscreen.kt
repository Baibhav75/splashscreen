package com.example.splashscreen

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class mainscreen : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainscreen)
        val randomColor = getRandomColour()
        findViewById<View>(R.id.textView2).setBackgroundColor(randomColor)

    }
    private fun getRandomColour():Int{
        val colors= intArrayOf(Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA, Color.CYAN)
        val randomIndex =(0 until colors.size).random()
        return colors[randomIndex]
    }

}